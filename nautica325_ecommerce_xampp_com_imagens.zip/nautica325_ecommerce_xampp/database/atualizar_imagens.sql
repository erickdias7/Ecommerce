-- Atualiza somente as imagens dos produtos; preserva os demais dados.
USE nautica325;

UPDATE produtos SET imagem='https://www.fibrafort.com.br/site/uploads/2024/05/242-GTO-out-sem-motor.webp' WHERE sku='N325-LAN-242';
UPDATE produtos SET imagem='https://img.olx.com.br/images/89/895686488806483.jpg' WHERE sku='N325-JET-GTI130';
UPDATE produtos SET imagem='https://www.yamahawaverunners.com/globalassets/media/my26/wr/recreation/vx-cruiser-ho/360-assets/82_2026_vx1900b-c_bk_na_11_yy_24-large.png' WHERE sku='N325-JET-VXHO';
UPDATE produtos SET imagem='https://img.olx.com.br/images/99/999620022390374.jpg' WHERE sku='N325-BAR-MAR600';
UPDATE produtos SET imagem='https://cdn2.yamaha-motor.eu/prod/product-assets/2026/F40/2026-Yamaha-F40-EU-Light_Grey_Metallic-Studio-001-03.jpg' WHERE sku='N325-MOT-Y40';
UPDATE produtos SET imagem='https://vifprop.com/cdn/shop/products/4Z5A0072_6003ccbb-9549-465c-bb96-b4d63679add9.jpg?v=1731638879' WHERE sku='N325-HEL-MERC-INX';
UPDATE produtos SET imagem='https://www.useprolife.com/cdn/shop/files/03_83fe6fcc-d018-4baf-8305-bc85b69a6351.png?v=1757450069&width=1500' WHERE sku='N325-SEG-COLETE-P';
