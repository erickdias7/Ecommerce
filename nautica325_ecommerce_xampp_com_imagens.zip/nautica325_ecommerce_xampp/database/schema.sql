CREATE DATABASE IF NOT EXISTS nautica325
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nautica325;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS itens_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE usuarios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  perfil ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_usuarios_perfil (perfil)
) ENGINE=InnoDB;

CREATE TABLE categorias (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL UNIQUE,
  slug VARCHAR(140) NOT NULL UNIQUE,
  ordem INT NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE produtos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  categoria_id BIGINT UNSIGNED NOT NULL,
  sku VARCHAR(60) NOT NULL UNIQUE,
  nome VARCHAR(160) NOT NULL,
  descricao TEXT NOT NULL,
  preco DECIMAL(12,2) NOT NULL,
  estoque INT UNSIGNED NOT NULL DEFAULT 0,
  imagem VARCHAR(255) NOT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  destaque TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  CONSTRAINT chk_produtos_preco CHECK (preco > 0),
  INDEX idx_produtos_categoria (categoria_id),
  INDEX idx_produtos_status_destaque (ativo,destaque),
  INDEX idx_produtos_nome (nome)
) ENGINE=InnoDB;

CREATE TABLE pedidos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id BIGINT UNSIGNED NOT NULL,
  forma_pagamento ENUM('PIX','Boleto','Cartão de Crédito') NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  status ENUM('confirmado','em_separacao','enviado','concluido','cancelado') NOT NULL DEFAULT 'confirmado',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  INDEX idx_pedidos_usuario (usuario_id),
  INDEX idx_pedidos_status_data (status,created_at)
) ENGINE=InnoDB;

CREATE TABLE itens_pedido (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id BIGINT UNSIGNED NOT NULL,
  produto_id BIGINT UNSIGNED NOT NULL,
  nome_produto VARCHAR(160) NOT NULL,
  sku VARCHAR(60) NOT NULL,
  quantidade INT UNSIGNED NOT NULL,
  preco_unitario DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
  CONSTRAINT chk_itens_quantidade CHECK (quantidade > 0),
  INDEX idx_itens_pedido (pedido_id),
  INDEX idx_itens_produto (produto_id)
) ENGINE=InnoDB;

INSERT INTO categorias (nome,slug,ordem) VALUES
('Barcos','barcos',1),
('Lanchas','lanchas',2),
('Jetskis','jetskis',3),
('Motores de Popa','motores-de-popa',4),
('Hélices','helices',5),
('Equipamentos de Segurança','equipamentos-de-seguranca',6),
('GPS e Navegação','gps-e-navegacao',7),
('Peças Náuticas','pecas-nauticas',8),
('Acessórios Náuticos','acessorios-nauticos',9),
('Manutenção','manutencao',10);

INSERT INTO produtos (categoria_id,sku,nome,descricao,preco,estoque,imagem,ativo,destaque) VALUES
(2,'N325-LAN-242','Lancha Focker 242 GTO','Lancha esportiva para passeios e lazer, com amplo espaço de convivência e acabamento premium. Produto demonstrativo para o projeto acadêmico.',359900.00,2,'https://www.fibrafort.com.br/site/uploads/2024/05/242-GTO-out-sem-motor.webp',1,1),
(3,'N325-JET-GTI130','Sea-Doo GTI 130','Jet ski versátil para aproveitar passeios e atividades recreativas. Produto demonstrativo para o projeto acadêmico.',79990.00,5,'https://img.olx.com.br/images/89/895686488806483.jpg',1,1),
(3,'N325-JET-VXHO','Yamaha VX Cruiser HO','Jet ski com proposta touring, ideal para passeios mais longos e conforto na água. Produto demonstrativo.',89900.00,4,'https://www.yamahawaverunners.com/globalassets/media/my26/wr/recreation/vx-cruiser-ho/360-assets/82_2026_vx1900b-c_bk_na_11_yy_24-large.png',1,1),
(1,'N325-BAR-MAR600','Barco Marujo 600','Barco versátil para pesca e lazer, com estrutura prática e espaço para os passeios do dia a dia.',49900.00,3,'https://img.olx.com.br/images/99/999620022390374.jpg',1,1),
(4,'N325-MOT-Y40','Motor Yamaha 40HP','Motor de popa de 40 HP para propulsão de embarcações compatíveis. Verifique a compatibilidade antes da compra.',24500.00,6,'https://cdn2.yamaha-motor.eu/prod/product-assets/2026/F40/2026-Yamaha-F40-EU-Light_Grey_Metallic-Studio-001-03.jpg',1,0),
(5,'N325-HEL-MERC-INX','Hélice Inox Mercury','Hélice em aço inoxidável para aplicação compatível com motores Mercury. Confirme medidas e especificações.',1490.00,10,'https://vifprop.com/cdn/shop/products/4Z5A0072_6003ccbb-9549-465c-bb96-b4d63679add9.jpg?v=1731638879',1,0),
(6,'N325-SEG-COLETE-P','Colete Salva-Vidas Premium','Equipamento de flutuação para atividades náuticas. Selecione tamanho e capacidade adequados ao usuário e siga as instruções do fabricante.',199.90,30,'https://www.useprolife.com/cdn/shop/files/03_83fe6fcc-d018-4baf-8305-bc85b69a6351.png?v=1757450069&width=1500',1,0);
