<?php
require __DIR__ . '/_guard.php';
$produtos = db()->query("SELECT p.*,c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id=p.categoria_id ORDER BY p.created_at DESC")->fetchAll();
$pageTitle = 'Gerenciar produtos';
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="page-heading"><div><span class="eyebrow">CATÁLOGO</span><h1>Gerenciar produtos</h1></div><a class="btn btn-gold" href="produto_form.php"><i class="bi bi-plus-lg"></i> Novo produto</a></div>
<div class="table-responsive table-card"><table class="table align-middle"><thead><tr><th>Produto</th><th>SKU</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Status</th><th>Ações</th></tr></thead><tbody>
<?php foreach ($produtos as $p): ?><tr><td><div class="table-product"><img src="<?= e(product_image($p['imagem'])) ?>" alt=""><b><?= e($p['nome']) ?></b></div></td><td><?= e($p['sku']) ?></td><td><?= e($p['categoria_nome']) ?></td><td><?= money($p['preco']) ?></td><td><?= (int)$p['estoque'] ?></td><td><span class="status-pill <?= $p['ativo']?'active':'inactive' ?>"><?= $p['ativo']?'Ativo':'Inativo' ?></span></td><td><a class="btn btn-outline-secondary btn-sm" href="produto_form.php?id=<?= (int)$p['id'] ?>">Editar</a><form method="post" action="produto_excluir.php" class="d-inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-outline-danger btn-sm" type="submit" onclick="return confirm('Excluir ou desativar este produto?')"><?= $p['ativo']?'Desativar':'Excluir' ?></button></form></td></tr><?php endforeach; ?>
</tbody></table></div></main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
