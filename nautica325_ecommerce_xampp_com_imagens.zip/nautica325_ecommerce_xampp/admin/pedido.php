<?php
require __DIR__ . '/_guard.php';
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$stmt = db()->prepare("SELECT p.*,u.nome AS cliente,u.email FROM pedidos p JOIN usuarios u ON u.id=p.usuario_id WHERE p.id=:id");
$stmt->execute(['id'=>$id ?: 0]);
$pedido = $stmt->fetch();
if (!$pedido) { flash('error','Pedido não encontrado.'); redirect('pedidos.php'); }
$itensStmt = db()->prepare("SELECT * FROM itens_pedido WHERE pedido_id=:id ORDER BY id");
$itensStmt->execute(['id'=>$id]);
$itens = $itensStmt->fetchAll();
$pageTitle = 'Pedido #' . $id;
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><a class="back-link" href="pedidos.php"><i class="bi bi-arrow-left"></i> Voltar aos pedidos</a><div class="page-heading"><div><span class="eyebrow">DETALHES DA VENDA</span><h1>Pedido #<?= (int)$pedido['id'] ?></h1></div></div>
<div class="order-detail-grid"><section class="table-card p-4"><h2>Itens comprados</h2><?php foreach($itens as $item): ?><div class="order-line"><span><b><?= e($item['nome_produto']) ?></b><small><?= e($item['sku']) ?> · <?= (int)$item['quantidade'] ?> unidade(s)</small></span><strong><?= money((float)$item['preco_unitario']*(int)$item['quantidade']) ?></strong></div><?php endforeach; ?><hr><div class="summary-row summary-total"><span>Total</span><strong><?= money($pedido['total']) ?></strong></div></section>
<aside class="summary-card"><span class="eyebrow">CLIENTE</span><h3><?= e($pedido['cliente']) ?></h3><p><?= e($pedido['email']) ?></p><hr><div class="summary-row"><span>Data</span><strong><?= e(date('d/m/Y H:i',strtotime($pedido['created_at']))) ?></strong></div><div class="summary-row"><span>Pagamento</span><strong><?= e($pedido['forma_pagamento']) ?></strong></div><div class="summary-row"><span>Status</span><strong><?= e($pedido['status']) ?></strong></div></aside></div></main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
