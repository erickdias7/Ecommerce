<?php
require __DIR__ . '/_guard.php';
$clientes = db()->query("SELECT u.id,u.nome,u.email,u.created_at,COUNT(p.id) AS pedidos,COALESCE(SUM(CASE WHEN p.status<>'cancelado' THEN p.total ELSE 0 END),0) AS total_compras FROM usuarios u LEFT JOIN pedidos p ON p.usuario_id=u.id WHERE u.perfil='cliente' GROUP BY u.id ORDER BY u.created_at DESC")->fetchAll();
$pageTitle = 'Clientes';
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="page-heading"><div><span class="eyebrow">RELACIONAMENTO</span><h1>Clientes cadastrados</h1></div></div><div class="table-responsive table-card"><table class="table align-middle"><thead><tr><th>Cliente</th><th>E-mail</th><th>Cadastro</th><th>Pedidos</th><th>Total comprado</th></tr></thead><tbody>
<?php foreach($clientes as $c): ?><tr><td><b><?= e($c['nome']) ?></b></td><td><?= e($c['email']) ?></td><td><?= e(date('d/m/Y',strtotime($c['created_at']))) ?></td><td><?= (int)$c['pedidos'] ?></td><td><?= money($c['total_compras']) ?></td></tr><?php endforeach; ?>
</tbody></table></div></main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
