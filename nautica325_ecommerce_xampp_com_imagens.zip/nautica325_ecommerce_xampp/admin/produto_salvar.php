<?php
require __DIR__ . '/_guard.php';
require_post();
verify_csrf();
$id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
$nome = trim((string)($_POST['nome'] ?? ''));
$sku = strtoupper(trim((string)($_POST['sku'] ?? '')));
$descricao = trim((string)($_POST['descricao'] ?? ''));
$preco = filter_var($_POST['preco'] ?? null, FILTER_VALIDATE_FLOAT);
$estoque = filter_var($_POST['estoque'] ?? null, FILTER_VALIDATE_INT);
$categoria = filter_var($_POST['categoria_id'] ?? null, FILTER_VALIDATE_INT);
$imagem = trim((string)($_POST['imagem'] ?? ''));
$ativo = isset($_POST['ativo']) ? 1 : 0;
$destaque = isset($_POST['destaque']) ? 1 : 0;

if ($nome==='' || $sku==='' || $descricao==='' || $preco===false || $preco<=0 || $estoque===false || $estoque<0 || !$categoria || !preg_match('/^[a-zA-Z0-9_\\-\\/\\.]+$/',$imagem) || strpos($imagem,'..')!==false) {
    flash('error','Verifique os campos. Preço, estoque, SKU e imagem devem ser válidos.');
    redirect($id?'produto_form.php?id='.$id:'produto_form.php');
}
try {
    if ($id) {
        $stmt = db()->prepare("UPDATE produtos SET categoria_id=:categoria,sku=:sku,nome=:nome,descricao=:descricao,preco=:preco,estoque=:estoque,imagem=:imagem,ativo=:ativo,destaque=:destaque WHERE id=:id");
        $stmt->execute(['categoria'=>$categoria,'sku'=>$sku,'nome'=>$nome,'descricao'=>$descricao,'preco'=>$preco,'estoque'=>$estoque,'imagem'=>$imagem,'ativo'=>$ativo,'destaque'=>$destaque,'id'=>$id]);
        flash('success','Produto atualizado.');
    } else {
        $stmt = db()->prepare("INSERT INTO produtos (categoria_id,sku,nome,descricao,preco,estoque,imagem,ativo,destaque) VALUES (:categoria,:sku,:nome,:descricao,:preco,:estoque,:imagem,:ativo,:destaque)");
        $stmt->execute(['categoria'=>$categoria,'sku'=>$sku,'nome'=>$nome,'descricao'=>$descricao,'preco'=>$preco,'estoque'=>$estoque,'imagem'=>$imagem,'ativo'=>$ativo,'destaque'=>$destaque]);
        flash('success','Produto cadastrado.');
    }
} catch(PDOException $e) {
    if ($e->getCode()==='23000') flash('error','Este SKU já está cadastrado.');
    else throw $e;
}
redirect('produtos.php');
