<?php
require __DIR__ . '/_guard.php';
require_post();
verify_csrf();
$id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$id) redirect('produtos.php');
$check = db()->prepare("SELECT COUNT(*) FROM itens_pedido WHERE produto_id=:id");
$check->execute(['id'=>$id]);
$temHistorico = (int)$check->fetchColumn() > 0;
if ($temHistorico) {
    $stmt = db()->prepare("UPDATE produtos SET ativo=0 WHERE id=:id");
    $stmt->execute(['id'=>$id]);
    flash('success','Produto desativado para preservar o histórico de pedidos.');
} else {
    $stmt = db()->prepare("DELETE FROM produtos WHERE id=:id");
    $stmt->execute(['id'=>$id]);
    flash('success','Produto excluído.');
}
redirect('produtos.php');
