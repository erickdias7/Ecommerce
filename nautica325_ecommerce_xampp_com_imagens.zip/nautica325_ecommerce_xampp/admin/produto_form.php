<?php
require __DIR__ . '/_guard.php';
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$p = ['id'=>0,'categoria_id'=>'','sku'=>'','nome'=>'','descricao'=>'','preco'=>'','estoque'=>0,'imagem'=>'assets/images/produto-generico.svg','ativo'=>1,'destaque'=>0];
if ($id) {
    $stmt = db()->prepare("SELECT * FROM produtos WHERE id=:id");
    $stmt->execute(['id'=>$id]);
    $found = $stmt->fetch();
    if (!$found) { flash('error','Produto não encontrado.'); redirect('produtos.php'); }
    $p = $found;
}
$categorias = db()->query("SELECT id,nome FROM categorias WHERE ativo=1 ORDER BY ordem,nome")->fetchAll();
$pageTitle = $id ? 'Editar produto' : 'Novo produto';
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><a class="back-link" href="produtos.php"><i class="bi bi-arrow-left"></i> Voltar aos produtos</a>
<form class="auth-card admin-form" method="post" action="produto_salvar.php"><span class="eyebrow">CATÁLOGO NÁUTICO</span><h1><?= $id?'Editar produto':'Cadastrar produto' ?></h1><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
<label>Nome<input class="form-control" name="nome" required maxlength="160" value="<?= e($p['nome']) ?>"></label>
<div class="row g-3"><div class="col-md-6"><label>SKU<input class="form-control" name="sku" required maxlength="60" value="<?= e($p['sku']) ?>"></label></div><div class="col-md-6"><label>Categoria<select class="form-select" name="categoria_id" required><?php foreach($categorias as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$p['categoria_id']===(int)$c['id']?'selected':'' ?>><?= e($c['nome']) ?></option><?php endforeach; ?></select></label></div></div>
<label>Descrição<textarea class="form-control" name="descricao" rows="5" required><?= e($p['descricao']) ?></textarea></label>
<div class="row g-3"><div class="col-md-4"><label>Preço (R$)<input class="form-control" name="preco" type="number" min="0.01" step="0.01" required value="<?= e($p['preco']) ?>"></label></div><div class="col-md-4"><label>Estoque<input class="form-control" name="estoque" type="number" min="0" step="1" required value="<?= (int)$p['estoque'] ?>"></label></div><div class="col-md-4"><label>Caminho da imagem<input class="form-control" name="imagem" maxlength="255" required value="<?= e($p['imagem']) ?>"></label></div></div>
<label class="form-check"><input class="form-check-input" type="checkbox" name="ativo" value="1" <?= $p['ativo']?'checked':'' ?>> Produto ativo</label><label class="form-check"><input class="form-check-input" type="checkbox" name="destaque" value="1" <?= $p['destaque']?'checked':'' ?>> Exibir em destaque</label>
<button class="btn btn-navy w-100">Salvar produto</button></form></main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
