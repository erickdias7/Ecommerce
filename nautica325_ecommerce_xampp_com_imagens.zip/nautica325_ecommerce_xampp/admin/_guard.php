<?php
require dirname(__DIR__) . '/app/bootstrap.php';
require_admin();
