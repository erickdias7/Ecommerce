<?php
require __DIR__ . '/_guard.php';
$pedidos = db()->query("SELECT p.*,u.nome AS cliente,u.email FROM pedidos p JOIN usuarios u ON u.id=p.usuario_id ORDER BY p.created_at DESC")->fetchAll();
$pageTitle = 'Pedidos';
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="page-heading"><div><span class="eyebrow">VENDAS</span><h1>Pedidos recebidos</h1></div><a class="text-link" href="index.php">Painel inicial</a></div>
<div class="table-responsive table-card"><table class="table align-middle"><thead><tr><th>Pedido</th><th>Cliente</th><th>Data</th><th>Pagamento</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach($pedidos as $p): ?><tr><td>#<?= (int)$p['id'] ?></td><td><?= e($p['cliente']) ?><small class="d-block text-muted"><?= e($p['email']) ?></small></td><td><?= e(date('d/m/Y H:i',strtotime($p['created_at']))) ?></td><td><?= e($p['forma_pagamento']) ?></td><td><?= money($p['total']) ?></td><td><?= e($p['status']) ?></td><td><a class="btn btn-outline-secondary btn-sm" href="pedido.php?id=<?= (int)$p['id'] ?>">Detalhes</a></td></tr><?php endforeach; ?>
</tbody></table></div></main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
