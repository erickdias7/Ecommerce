<?php
require __DIR__ . '/_guard.php';
$produtos = (int)db()->query("SELECT COUNT(*) FROM produtos")->fetchColumn();
$pedidos = (int)db()->query("SELECT COUNT(*) FROM pedidos")->fetchColumn();
$clientes = (int)db()->query("SELECT COUNT(*) FROM usuarios WHERE perfil='cliente'")->fetchColumn();
$faturamento = (float)db()->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE status <> 'cancelado'")->fetchColumn();
$pageTitle = 'Painel administrativo';
require dirname(__DIR__) . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="page-heading"><div><span class="eyebrow">ÁREA RESTRITA</span><h1>Painel administrativo</h1><p>Gestão da operação Náutica325.</p></div></div>
<div class="admin-stats"><article><span>Produtos</span><strong><?= $produtos ?></strong><i class="bi bi-box-seam"></i></article><article><span>Pedidos</span><strong><?= $pedidos ?></strong><i class="bi bi-receipt"></i></article><article><span>Clientes</span><strong><?= $clientes ?></strong><i class="bi bi-people"></i></article><article><span>Faturamento</span><strong><?= money($faturamento) ?></strong><i class="bi bi-currency-dollar"></i></article></div>
<div class="admin-nav-cards"><a href="produtos.php"><i class="bi bi-box-seam"></i><span><b>Produtos</b><small>Cadastrar, editar e desativar</small></span><i class="bi bi-arrow-up-right"></i></a><a href="pedidos.php"><i class="bi bi-receipt"></i><span><b>Pedidos</b><small>Consultar compras e itens</small></span><i class="bi bi-arrow-up-right"></i></a><a href="clientes.php"><i class="bi bi-people"></i><span><b>Clientes</b><small>Visualizar cadastros</small></span><i class="bi bi-arrow-up-right"></i></a></div>
</main>
<?php require dirname(__DIR__) . '/app/views/footer.php'; ?>
