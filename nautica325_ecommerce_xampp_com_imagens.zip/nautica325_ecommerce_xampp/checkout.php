<?php
require __DIR__ . '/app/bootstrap.php';
require_login();
$carrinho = cart_details();
if (!$carrinho['itens']) {
    flash('error','Adicione produtos ao carrinho antes de finalizar.');
    redirect('carrinho.php');
}
$pageTitle = 'Finalizar compra';
require __DIR__ . '/app/views/header.php';
?>
<main class="container page-wrap"><a class="back-link" href="carrinho.php"><i class="bi bi-arrow-left"></i> Voltar ao carrinho</a><div class="page-heading"><div><span class="eyebrow">ÚLTIMA ETAPA</span><h1>Finalizar pedido</h1></div></div>
<div class="cart-layout">
<form method="post" action="finalizar_pedido.php" class="auth-card checkout-card"><?= csrf_field() ?><h2>Forma de pagamento</h2><p class="muted">Simulação acadêmica. Nenhuma cobrança real será realizada.</p>
<label class="payment-option"><input type="radio" name="forma_pagamento" value="PIX" checked><span><strong>PIX</strong><small>Confirmação simulada</small></span><i class="bi bi-qr-code"></i></label>
<label class="payment-option"><input type="radio" name="forma_pagamento" value="Boleto"><span><strong>Boleto</strong><small>Pagamento demonstrativo</small></span><i class="bi bi-upc"></i></label>
<label class="payment-option"><input type="radio" name="forma_pagamento" value="Cartão de Crédito"><span><strong>Cartão de Crédito</strong><small>Não são coletados dados bancários reais</small></span><i class="bi bi-credit-card"></i></label>
<button class="btn btn-gold w-100 mt-3">Confirmar compra <i class="bi bi-check2"></i></button></form>
<aside class="summary-card"><span class="eyebrow">RESUMO</span><?php foreach ($carrinho['itens'] as $item): ?><div class="summary-row"><span><?= e($item['nome']) ?> × <?= (int)$item['quantidade'] ?></span><strong><?= money($item['subtotal']) ?></strong></div><?php endforeach; ?><hr><div class="summary-row summary-total"><span>Total</span><strong><?= money($carrinho['total']) ?></strong></div></aside>
</div></main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
