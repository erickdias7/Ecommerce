<?php
require __DIR__ . '/app/bootstrap.php';
$carrinho = cart_details();
$pageTitle = 'Meu carrinho';
require __DIR__ . '/app/views/header.php';
?>
<main class="container page-wrap">
 <div class="page-heading"><div><span class="eyebrow">SUA SELEÇÃO</span><h1>Meu carrinho</h1></div><a href="index.php" class="text-link">Continuar comprando <i class="bi bi-arrow-right"></i></a></div>
 <?php if (!$carrinho['itens']): ?>
  <div class="empty-state"><i class="bi bi-bag"></i><h2>Seu carrinho está vazio</h2><p>Explore a loja e encontre seu próximo item náutico.</p><a class="btn btn-navy" href="index.php">Ver produtos</a></div>
 <?php else: ?>
  <div class="cart-layout">
   <div class="cart-items">
    <?php foreach ($carrinho['itens'] as $item): ?>
     <article class="cart-item">
      <img src="<?= e(product_image($item['imagem'])) ?>" alt="<?= e($item['nome']) ?>">
      <div class="cart-item-info"><small><?= e($item['categoria_nome']) ?> · <?= e($item['sku']) ?></small><h3><?= e($item['nome']) ?></h3><strong><?= money($item['preco']) ?></strong></div>
      <form method="post" action="atualizar_carrinho.php" class="quantity-form"><?= csrf_field() ?><input type="hidden" name="produto_id" value="<?= (int)$item['id'] ?>"><label class="visually-hidden" for="q<?= (int)$item['id'] ?>">Quantidade</label><input class="form-control" id="q<?= (int)$item['id'] ?>" type="number" name="quantidade" min="1" max="<?= (int)$item['estoque'] ?>" value="<?= (int)$item['quantidade'] ?>"><button class="btn btn-outline-secondary btn-sm" type="submit">Atualizar</button></form>
      <div class="cart-line-total"><?= money($item['subtotal']) ?></div>
      <form method="post" action="remover_carrinho.php"><?= csrf_field() ?><input type="hidden" name="produto_id" value="<?= (int)$item['id'] ?>"><button class="remove-button" type="submit" aria-label="Remover item"><i class="bi bi-trash3"></i></button></form>
     </article>
    <?php endforeach; ?>
   </div>
   <aside class="summary-card"><span class="eyebrow">RESUMO DO PEDIDO</span><div class="summary-row"><span>Subtotal</span><strong><?= money($carrinho['total']) ?></strong></div><div class="summary-row"><span>Frete</span><strong>A calcular</strong></div><hr><div class="summary-row summary-total"><span>Total parcial</span><strong><?= money($carrinho['total']) ?></strong></div><a href="checkout.php" class="btn btn-navy w-100">Continuar para pagamento <i class="bi bi-arrow-right"></i></a><p class="summary-note">O pagamento é simulado para fins acadêmicos.</p></aside>
  </div>
 <?php endif; ?>
</main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
