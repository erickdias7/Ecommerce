<?php
require __DIR__ . '/app/bootstrap.php';

$busca = trim((string)($_GET['busca'] ?? ''));
$categoriaId = filter_var($_GET['categoria'] ?? '', FILTER_VALIDATE_INT);
$categoriaId = $categoriaId ? (int)$categoriaId : null;
$precoMin = (isset($_GET['preco_min']) && $_GET['preco_min'] !== '') ? filter_var($_GET['preco_min'], FILTER_VALIDATE_FLOAT) : null;
$precoMax = (isset($_GET['preco_max']) && $_GET['preco_max'] !== '') ? filter_var($_GET['preco_max'], FILTER_VALIDATE_FLOAT) : null;
$ordenacao = (string)($_GET['ordenar'] ?? 'destaque');

$sql = "SELECT p.*, c.nome AS categoria_nome
        FROM produtos p
        INNER JOIN categorias c ON c.id = p.categoria_id
        WHERE p.ativo = 1";
$params = [];

if ($busca !== '') {
    $sql .= " AND (p.nome LIKE :busca_nome OR p.descricao LIKE :busca_desc OR p.sku LIKE :busca_sku)";
    $like = '%' . $busca . '%';
    $params['busca_nome'] = $like;
    $params['busca_desc'] = $like;
    $params['busca_sku'] = $like;
}
if ($categoriaId) {
    $sql .= " AND p.categoria_id = :categoria";
    $params['categoria'] = $categoriaId;
}
if ($precoMin !== null && $precoMin !== false && $precoMin >= 0) {
    $sql .= " AND p.preco >= :preco_min";
    $params['preco_min'] = $precoMin;
}
if ($precoMax !== null && $precoMax !== false && $precoMax >= 0) {
    $sql .= " AND p.preco <= :preco_max";
    $params['preco_max'] = $precoMax;
}

$orderBy = "p.destaque DESC, p.created_at DESC";
if ($ordenacao === 'menor_preco') $orderBy = "p.preco ASC";
if ($ordenacao === 'maior_preco') $orderBy = "p.preco DESC";
if ($ordenacao === 'nome') $orderBy = "p.nome ASC";
$sql .= " ORDER BY " . $orderBy;

$stmt = db()->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();
$categorias = db()->query("SELECT id, nome FROM categorias WHERE ativo = 1 ORDER BY ordem, nome")->fetchAll();
$destaques = db()->query("SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id=p.categoria_id WHERE p.ativo=1 AND p.destaque=1 ORDER BY p.id LIMIT 4")->fetchAll();
$maisVendidos = db()->query("SELECT p.*, c.nome AS categoria_nome, COALESCE(v.vendidos,0) AS vendidos
    FROM produtos p
    JOIN categorias c ON c.id=p.categoria_id
    LEFT JOIN (
        SELECT ip.produto_id, SUM(ip.quantidade) AS vendidos
        FROM itens_pedido ip
        JOIN pedidos ped ON ped.id=ip.pedido_id
        WHERE ped.status <> 'cancelado'
        GROUP BY ip.produto_id
    ) v ON v.produto_id=p.id
    WHERE p.ativo=1
    ORDER BY COALESCE(v.vendidos,0) DESC, p.destaque DESC
    LIMIT 4")->fetchAll();

$pageTitle = 'Sua aventura começa nas águas';
require __DIR__ . '/app/views/header.php';
?>
<main>
<section class="hero-nautico">
  <div class="hero-overlay"></div>
  <div class="container hero-content">
    <span class="eyebrow light">NÁUTICA325 · EXPERIÊNCIA SOBRE AS ÁGUAS</span>
    <h1>Sua aventura<br><em>começa nas águas.</em></h1>
    <p>Embarcações, motores e equipamentos selecionados para quem leva a liberdade a sério.</p>
    <div class="hero-actions">
      <a class="btn btn-gold btn-lg" href="#catalogo">Explorar produtos <i class="bi bi-arrow-up-right"></i></a>
      <a class="btn btn-outline-light btn-lg" href="#categorias">Ver categorias</a>
    </div>
    <div class="hero-proof"><span><i class="bi bi-shield-check"></i> Compra segura</span><span><i class="bi bi-compass"></i> Especialistas náuticos</span></div>
  </div>
  <div class="hero-mark">325<span>MARINE</span></div>
</section>

<section class="container trust-strip">
  <div><i class="bi bi-truck"></i><span><strong>Entrega especializada</strong><small>Logística para produtos náuticos</small></span></div>
  <div><i class="bi bi-patch-check"></i><span><strong>Seleção de qualidade</strong><small>Marcas e produtos selecionados</small></span></div>
  <div><i class="bi bi-headset"></i><span><strong>Atendimento dedicado</strong><small>Suporte para sua navegação</small></span></div>
</section>

<section class="section-space container" id="categorias">
  <div class="section-heading"><div><span class="eyebrow">ENCONTRE O QUE PROCURA</span><h2>Explore por <em>categoria</em></h2></div><p>Do primeiro passeio à próxima grande expedição.</p></div>
  <div class="category-grid">
    <?php
    $categoryIcons = ['Barcos'=>'bi-water','Lanchas'=>'bi-sailboat','Jetskis'=>'bi-speedometer2','Motores de Popa'=>'bi-gear-wide-connected','Hélices'=>'bi-fan','Equipamentos de Segurança'=>'bi-life-preserver','GPS e Navegação'=>'bi-compass','Peças Náuticas'=>'bi-tools','Acessórios Náuticos'=>'bi-stars','Manutenção'=>'bi-wrench-adjustable'];
    foreach ($categorias as $categoria):
      $icon = $categoryIcons[$categoria['nome']] ?? 'bi-water';
    ?>
      <a class="category-tile" href="index.php?categoria=<?= (int)$categoria['id'] ?>#catalogo">
        <span class="category-icon"><i class="bi <?= e($icon) ?>"></i></span>
        <strong><?= e($categoria['nome']) ?></strong>
        <i class="bi bi-arrow-up-right category-arrow"></i>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="section-space section-soft" id="destaques">
 <div class="container">
  <div class="section-heading"><div><span class="eyebrow">ESCOLHAS DA NÁUTICA325</span><h2>Produtos em <em>destaque</em></h2></div><a href="#catalogo" class="text-link">Ver catálogo completo <i class="bi bi-arrow-right"></i></a></div>
  <div class="product-grid">
   <?php foreach ($destaques as $produto): require __DIR__ . '/app/views/product_card.php'; endforeach; ?>
  </div>
 </div>
</section>

<section class="section-space container" id="catalogo">
 <div class="section-heading"><div><span class="eyebrow">CATÁLOGO NÁUTICO</span><h2>Encontre seu próximo <em>destino</em></h2></div><p><?= count($produtos) ?> produto(s) disponíveis</p></div>
 <form class="filter-panel" method="get" action="index.php">
  <label class="search-field"><i class="bi bi-search"></i><input type="search" name="busca" value="<?= e($busca) ?>" placeholder="Buscar por produto, descrição ou SKU"></label>
  <select class="form-select" name="categoria"><option value="">Todas as categorias</option><?php foreach ($categorias as $categoria): ?><option value="<?= (int)$categoria['id'] ?>" <?= $categoriaId === (int)$categoria['id'] ? 'selected' : '' ?>><?= e($categoria['nome']) ?></option><?php endforeach; ?></select>
  <input class="form-control price-filter" type="number" min="0" step="0.01" name="preco_min" value="<?= e($_GET['preco_min'] ?? '') ?>" placeholder="Preço mínimo">
  <input class="form-control price-filter" type="number" min="0" step="0.01" name="preco_max" value="<?= e($_GET['preco_max'] ?? '') ?>" placeholder="Preço máximo">
  <select class="form-select sort-select" name="ordenar"><option value="destaque">Destaques</option><option value="menor_preco" <?= $ordenacao==='menor_preco'?'selected':'' ?>>Menor preço</option><option value="maior_preco" <?= $ordenacao==='maior_preco'?'selected':'' ?>>Maior preço</option><option value="nome" <?= $ordenacao==='nome'?'selected':'' ?>>Nome</option></select>
  <button class="btn btn-navy" type="submit">Filtrar</button>
  <?php if ($busca !== '' || $categoriaId || isset($_GET['preco_min']) || isset($_GET['preco_max'])): ?><a class="btn btn-outline-secondary" href="index.php#catalogo">Limpar</a><?php endif; ?>
 </form>
 <?php if (!$produtos): ?>
  <div class="empty-state"><i class="bi bi-search"></i><h3>Nenhum produto encontrado</h3><p>Altere os filtros e tente novamente.</p></div>
 <?php else: ?>
  <div class="product-grid"><?php foreach ($produtos as $produto): require __DIR__ . '/app/views/product_card.php'; endforeach; ?></div>
 <?php endif; ?>
</section>

<section class="section-space section-dark">
 <div class="container best-sellers">
  <div><span class="eyebrow gold">MAIS PROCURADOS</span><h2>Preferidos de quem<br><em>vive o mar.</em></h2><p>Confira os itens com maior volume de vendas registradas nesta loja demonstrativa.</p><a href="#catalogo" class="btn btn-gold">Ver todos os produtos</a></div>
  <div class="mini-products"><?php foreach ($maisVendidos as $produto): ?><a class="mini-product" href="produto.php?id=<?= (int)$produto['id'] ?>"><img src="<?= e(product_image($produto['imagem'])) ?>" alt="<?= e($produto['nome']) ?>"><span><small><?= e($produto['categoria_nome']) ?></small><strong><?= e($produto['nome']) ?></strong><b><?= money($produto['preco']) ?></b></span><i class="bi bi-arrow-up-right"></i></a><?php endforeach; ?></div>
 </div>
</section>

<section class="container section-space about-band">
 <div class="about-icon"><i class="bi bi-compass"></i><span>325</span></div>
 <div><span class="eyebrow">SOBRE A NÁUTICA325</span><h2>Mais do que produtos.<br><em>Uma vida em movimento.</em></h2><p>A Náutica325 conecta apaixonados pelo universo náutico a embarcações, motores e equipamentos que acompanham cada jornada. Nossa proposta é reunir variedade, informação e praticidade em uma experiência de compra simples e confiável.</p></div>
</section>
</main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
