<?php
require __DIR__ . '/app/bootstrap.php';
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$stmt = db()->prepare("SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id=p.categoria_id WHERE p.id=:id AND p.ativo=1 LIMIT 1");
$stmt->execute(['id' => $id ?: 0]);
$produto = $stmt->fetch();
if (!$produto) {
    http_response_code(404);
    $pageTitle = 'Produto não encontrado';
    require __DIR__ . '/app/views/header.php';
    echo '<main class="container page-wrap"><div class="empty-state"><h1>Produto não encontrado</h1><a class="btn btn-navy" href="index.php">Voltar à loja</a></div></main>';
    require __DIR__ . '/app/views/footer.php';
    exit;
}
$pageTitle = $produto['nome'];
require __DIR__ . '/app/views/header.php';
?>
<main class="container page-wrap">
 <a class="back-link" href="index.php"><i class="bi bi-arrow-left"></i> Voltar para a loja</a>
 <div class="product-detail">
  <div class="product-detail-image"><img src="<?= e(product_image($produto['imagem'])) ?>" alt="<?= e($produto['nome']) ?>"></div>
  <div class="product-detail-copy">
   <span class="eyebrow"><?= e($produto['categoria_nome']) ?> · SKU <?= e($produto['sku']) ?></span>
   <h1><?= e($produto['nome']) ?></h1>
   <div class="detail-price"><?= money($produto['preco']) ?></div>
   <p><?= nl2br(e($produto['descricao'])) ?></p>
   <p class="stock-indicator <?= (int)$produto['estoque'] > 0 ? 'in-stock' : 'out-stock' ?>">
    <i class="bi <?= (int)$produto['estoque'] > 0 ? 'bi-check-circle-fill' : 'bi-x-circle-fill' ?>"></i>
    <?= (int)$produto['estoque'] > 0 ? 'Disponível · ' . (int)$produto['estoque'] . ' unidade(s) em estoque' : 'Produto indisponível no momento' ?>
   </p>
   <?php if ((int)$produto['estoque'] > 0): ?>
   <form class="add-cart-form" method="post" action="adicionar_carrinho.php">
    <?= csrf_field() ?><input type="hidden" name="produto_id" value="<?= (int)$produto['id'] ?>">
    <label for="quantidade">Quantidade</label>
    <div class="d-flex gap-2"><input class="form-control quantity-input" id="quantidade" type="number" name="quantidade" min="1" max="<?= (int)$produto['estoque'] ?>" value="1" required><button class="btn btn-gold flex-grow-1" type="submit"><i class="bi bi-bag-plus"></i> Adicionar ao carrinho</button></div>
   </form>
   <?php else: ?><button class="btn btn-outline-secondary" disabled>Indisponível</button><?php endif; ?>
   <div class="product-assurances"><span><i class="bi bi-shield-check"></i> Compra segura</span><span><i class="bi bi-truck"></i> Consulte entrega</span></div>
  </div>
 </div>
</main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
