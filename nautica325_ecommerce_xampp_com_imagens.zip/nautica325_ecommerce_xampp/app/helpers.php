<?php

function base_path(): string {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    return strpos($script, '/admin/') !== false ? '../' : '';
}

function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function money($valor): string {
    return 'R$ ' . number_format((float)$valor, 2, ',', '.');
}
function redirect(string $destino): void {
    header('Location: ' . $destino);
    exit;
}
function require_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Método não permitido.');
    }
}
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    $token = (string)($_POST['_csrf'] ?? '');
    if ($token === '' || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Sessão expirada. Atualize a página e tente novamente.');
    }
}
function flash(string $tipo, string $mensagem): void {
    $_SESSION['_flash'][] = ['tipo'=>$tipo,'mensagem'=>$mensagem];
}
function consume_flashes(): array {
    $lista = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $lista;
}
function product_image_fallback(): string {
    return base_path() . 'assets/images/produto-generico.svg';
}

function product_image(?string $imagem): string {
    $imagem = trim((string)$imagem);
    $fallback = product_image_fallback();

    if ($imagem === '') {
        return $fallback;
    }

    if (filter_var($imagem, FILTER_VALIDATE_URL)) {
        $parts = parse_url($imagem);
        $host = strtolower($parts['host'] ?? '');
        $allowedHosts = [
            'www.fibrafort.com.br', 'img.olx.com.br',
            'www.yamahawaverunners.com', 'cdn2.yamaha-motor.eu',
            'vifprop.com', 'www.useprolife.com'
        ];
        if (($parts['scheme'] ?? '') === 'https' && in_array($host, $allowedHosts, true)) {
            return $imagem;
        }
        return $fallback;
    }

    if (strpos($imagem, '..') !== false || !preg_match('/^[a-zA-Z0-9_\-\/\.]+$/', $imagem)) {
        return $fallback;
    }
    return base_path() . $imagem;
}
function cart_count(): int {
    return array_sum(array_map('intval', $_SESSION['carrinho'] ?? []));
}
function cart_details(): array {
    $carrinho = $_SESSION['carrinho'] ?? [];
    $ids = [];
    foreach ($carrinho as $id => $qtd) {
        $id = (int)$id;
        if ($id > 0) $ids[] = $id;
    }
    if (!$ids) return ['itens'=>[],'total'=>0.0];

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT p.*,c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id=p.categoria_id WHERE p.id IN ($placeholders) AND p.ativo=1");
    $stmt->execute($ids);
    $produtos = $stmt->fetchAll();
    $itens = [];
    $total = 0.0;

    foreach ($produtos as $produto) {
        $id = (int)$produto['id'];
        $qtd = (int)($carrinho[$id] ?? 0);
        if ($qtd < 1 || (int)$produto['estoque'] < 1) {
            unset($_SESSION['carrinho'][$id]);
            continue;
        }
        if ($qtd > (int)$produto['estoque']) $qtd = (int)$produto['estoque'];
        $_SESSION['carrinho'][$id] = $qtd;
        $produto['quantidade'] = $qtd;
        $produto['subtotal'] = (float)$produto['preco'] * $qtd;
        $total += $produto['subtotal'];
        $itens[] = $produto;
    }
    return ['itens'=>$itens,'total'=>$total];
}
