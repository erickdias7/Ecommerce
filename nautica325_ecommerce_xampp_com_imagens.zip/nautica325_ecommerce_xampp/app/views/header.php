<?php
$flashMessages = consume_flashes();
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Náutica325 — embarcações, motores e equipamentos. Sua aventura começa nas águas.">
<title><?= e($pageTitle ?? 'Loja náutica') ?> | Náutica325</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= e(base_path()) ?>assets/css/style.css">
</head>
<body>
<header class="site-header">
 <div class="topline"><div class="container d-flex justify-content-between"><span>O universo náutico em um só lugar</span><span><i class="bi bi-whatsapp"></i> Atendimento especializado</span></div></div>
 <nav class="navbar navbar-expand-lg"><div class="container nav-shell">
  <a href="<?= e(base_path()) ?>index.php" class="brand"><span class="brand-mark"><i class="bi bi-compass-fill"></i></span><span>NÁUTICA<span class="brand-gold">325</span><small>SUA AVENTURA COMEÇA NAS ÁGUAS</small></span></a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Abrir menu"><span class="navbar-toggler-icon"></span></button>
  <div class="collapse navbar-collapse" id="mainNav">
   <ul class="navbar-nav ms-auto align-items-lg-center">
    <li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>index.php">Início</a></li><li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>index.php#catalogo">Produtos</a></li><li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>index.php#categorias">Categorias</a></li>
    <?php if (current_user()): ?>
      <li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>meus_pedidos.php">Meus pedidos</a></li>
      <?php if (current_user()['perfil']==='admin'): ?><li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>admin/index.php">Administração</a></li><?php endif; ?>
      <li class="nav-item"><form method="post" action="<?= e(base_path()) ?>logout.php" class="m-0"><?= csrf_field() ?><button class="nav-link nav-button" type="submit">Sair</button></form></li>
    <?php else: ?>
      <li class="nav-item"><a class="nav-link" href="<?= e(base_path()) ?>login.php">Entrar</a></li><li class="nav-item"><a class="nav-link nav-register" href="<?= e(base_path()) ?>cadastro.php">Criar conta</a></li>
    <?php endif; ?>
    <li class="nav-item"><a href="<?= e(base_path()) ?>carrinho.php" class="cart-link"><i class="bi bi-bag"></i><span><?= cart_count() ?></span></a></li>
   </ul>
  </div>
 </div></nav>
</header>
<?php foreach ($flashMessages as $msg): ?><div class="container flash-area"><div class="alert alert-<?= $msg['tipo']==='error'?'danger':'success' ?> alert-dismissible fade show"><?= e($msg['mensagem']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div><?php endforeach; ?>
