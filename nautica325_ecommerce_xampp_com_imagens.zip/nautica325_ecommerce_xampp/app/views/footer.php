<footer class="site-footer"><div class="container">
 <div class="footer-main">
  <div><a href="<?= e(base_path()) ?>index.php" class="brand footer-brand"><span class="brand-mark"><i class="bi bi-compass-fill"></i></span><span>NÁUTICA<span class="brand-gold">325</span><small>SUA AVENTURA COMEÇA NAS ÁGUAS</small></span></a><p>Conectando você ao melhor do universo náutico com qualidade, confiança e paixão pelo mar.</p></div>
  <div><h3>Institucional</h3><a href="<?= e(base_path()) ?>index.php#sobre">Sobre a Náutica325</a><a href="<?= e(base_path()) ?>index.php#catalogo">Produtos</a><a href="<?= e(base_path()) ?>meus_pedidos.php">Meus pedidos</a></div>
  <div><h3>Atendimento</h3><span><i class="bi bi-clock"></i> Seg. a Sex. · 9h às 18h</span><span><i class="bi bi-envelope"></i> contato@nautica325.com.br</span><span><i class="bi bi-geo-alt"></i> Atendimento online</span></div>
  <div><h3>Segurança</h3><span><i class="bi bi-shield-check"></i> Ambiente demonstrativo</span><span><i class="bi bi-credit-card"></i> Pagamento simulado</span></div>
 </div>
 <div class="footer-bottom"><span>© <?= date('Y') ?> Náutica325. Projeto acadêmico.</span><span>Sua aventura começa nas águas.</span></div>
</div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><script src="<?= e(base_path()) ?>assets/js/app.js"></script>
</body></html>
