<article class="product-card">
 <a href="produto.php?id=<?= (int)$produto['id'] ?>" class="product-image"><img src="<?= e(product_image($produto['imagem'])) ?>" alt="<?= e($produto['nome']) ?>" loading="lazy"><?php if ((int)$produto['estoque']>0 && (int)$produto['estoque']<=3): ?><span class="stock-badge">Últimas unidades</span><?php endif; ?></a>
 <div class="product-card-body"><small><?= e($produto['categoria_nome']) ?> · SKU <?= e($produto['sku']) ?></small><h3><a href="produto.php?id=<?= (int)$produto['id'] ?>"><?= e($produto['nome']) ?></a></h3><div class="product-card-bottom"><strong><?= money($produto['preco']) ?></strong><a href="produto.php?id=<?= (int)$produto['id'] ?>" aria-label="Ver <?= e($produto['nome']) ?>"><i class="bi bi-arrow-up-right"></i></a></div></div>
</article>
