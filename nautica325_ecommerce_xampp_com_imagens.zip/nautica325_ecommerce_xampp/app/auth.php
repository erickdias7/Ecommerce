<?php
function current_user(): ?array {
    return $_SESSION['usuario'] ?? null;
}
function require_login(): void {
    if (!current_user()) {
        flash('error','Entre na sua conta para continuar.');
        redirect('login.php');
    }
}
function require_admin(): void {
    if (!current_user() || current_user()['perfil'] !== 'admin') {
        http_response_code(403);
        exit('Acesso negado. Área exclusiva para administradores.');
    }
}
