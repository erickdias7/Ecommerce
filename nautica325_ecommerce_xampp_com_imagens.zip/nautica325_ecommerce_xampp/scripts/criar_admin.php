<?php
// Execute no terminal do XAMPP: php scripts/criar_admin.php admin@nautica325.local "SenhaForte123!" "Administrador"
require dirname(__DIR__) . '/app/bootstrap.php';
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Execute este script somente pelo terminal.\n");
}
$email = strtolower(trim($argv[1] ?? ''));
$senha = (string)($argv[2] ?? '');
$nome = trim($argv[3] ?? 'Administrador');

if (!filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($senha)<10 || $nome==='') {
    fwrite(STDERR,"Uso: php scripts/criar_admin.php email senha_forte [nome]\nA senha deve conter pelo menos 10 caracteres.\n");
    exit(1);
}
$check = db()->prepare("SELECT id FROM usuarios WHERE email=:email LIMIT 1");
$check->execute(['email'=>$email]);
if ($check->fetch()) {
    fwrite(STDERR,"Este e-mail já está cadastrado. Use outro e-mail para o administrador.\n");
    exit(1);
}
$insert = db()->prepare("INSERT INTO usuarios (nome,email,senha,perfil) VALUES (:nome,:email,:senha,'admin')");
$insert->execute(['nome'=>$nome,'email'=>$email,'senha'=>password_hash($senha,PASSWORD_DEFAULT)]);
echo "Administrador criado com sucesso: {$email}\n";
