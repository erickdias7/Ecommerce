document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-confirm]').forEach((button) => {
    button.addEventListener('click', (event) => {
      const message = button.getAttribute('data-confirm') || 'Deseja continuar?';
      if (!window.confirm(message)) event.preventDefault();
    });
  });

  // Pequena melhoria de experiência para os campos numéricos de estoque/quantidade.
  document.querySelectorAll('input[type="number"][min]').forEach((field) => {
    field.addEventListener('change', () => {
      const min = Number(field.min || 0);
      const max = field.max !== '' ? Number(field.max) : Number.POSITIVE_INFINITY;
      let value = Number(field.value || min);
      value = Math.max(min, Math.min(max, value));
      field.value = String(value);
    });
  });
});
