<?php
require __DIR__ . '/app/bootstrap.php';
require_login();
$id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$stmt = db()->prepare("SELECT id,total,forma_pagamento,created_at FROM pedidos WHERE id=:id AND usuario_id=:usuario LIMIT 1");
$stmt->execute(['id'=>$id ?: 0,'usuario'=>current_user()['id']]);
$pedido = $stmt->fetch();
if (!$pedido) redirect('index.php');
$pageTitle = 'Pedido confirmado';
require __DIR__ . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="success-card"><div class="success-icon"><i class="bi bi-check2"></i></div><span class="eyebrow">PEDIDO REGISTRADO</span><h1>Compra concluída!</h1><p>Seu pedido <strong>#<?= (int)$pedido['id'] ?></strong> foi registrado com sucesso na simulação.</p><div class="success-details"><span>Pagamento: <strong><?= e($pedido['forma_pagamento']) ?></strong></span><span>Total: <strong><?= money($pedido['total']) ?></strong></span></div><a class="btn btn-navy" href="meus_pedidos.php">Ver meus pedidos</a></div></main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
