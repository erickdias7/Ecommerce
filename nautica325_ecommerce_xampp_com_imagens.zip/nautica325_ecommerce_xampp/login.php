<?php
require __DIR__ . '/app/bootstrap.php';
if (current_user()) redirect('index.php');
$erro = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $senha = (string)($_POST['senha'] ?? '');
    $stmt = db()->prepare("SELECT id,nome,email,senha,perfil FROM usuarios WHERE email=:email LIMIT 1");
    $stmt->execute(['email'=>$email]);
    $usuario = $stmt->fetch();
    if ($usuario && password_verify($senha, $usuario['senha'])) {
        session_regenerate_id(true);
        $_SESSION['usuario'] = ['id'=>(int)$usuario['id'],'nome'=>$usuario['nome'],'email'=>$usuario['email'],'perfil'=>$usuario['perfil']];
        flash('success','Login realizado com sucesso.');
        redirect($usuario['perfil'] === 'admin' ? 'admin/index.php' : 'index.php');
    }
    $erro = 'E-mail ou senha incorretos.';
}
$pageTitle = 'Entrar';
require __DIR__ . '/app/views/header.php';
?>
<main class="container auth-wrap"><form class="auth-card" method="post"><span class="eyebrow">BEM-VINDO DE VOLTA</span><h1>Acesse sua conta</h1><p>Entre para acompanhar seus pedidos e finalizar compras.</p><?= csrf_field() ?>
<?php if ($erro): ?><div class="alert alert-danger"><?= e($erro) ?></div><?php endif; ?>
<label>E-mail<input class="form-control" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label>
<label>Senha<input class="form-control" type="password" name="senha" required></label>
<button class="btn btn-navy w-100 mt-3">Entrar</button><p class="auth-note">Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a></p></form></main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
