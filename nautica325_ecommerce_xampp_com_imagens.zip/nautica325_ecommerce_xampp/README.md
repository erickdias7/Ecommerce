# Náutica325 — E-commerce náutico

**Slogan:** Sua aventura começa nas águas.

Aplicação web acadêmica de comércio eletrônico desenvolvida com HTML5, CSS3, Bootstrap 5, JavaScript, PHP 8+ e MySQL/MariaDB com PDO. O tema visual usa azul-marinho, azul-oceano, branco e dourado.

> Os produtos e pedidos iniciais são dados demonstrativos. O checkout simula a confirmação do método de pagamento; não realiza cobranças reais.

## 1. Requisitos

- XAMPP com Apache e MySQL/MariaDB.
- Extensão PHP `mbstring` habilitada (usada na validação de nome).
- PHP 8.0 ou superior.
- Extensão `pdo_mysql` habilitada no PHP.
- Navegador atualizado.

## 2. Instalação no XAMPP

1. Copie a pasta `nautica325` para `C:\\xampp\\htdocs\\nautica325`.
2. Abra o painel do XAMPP e inicie **Apache** e **MySQL**.
3. Entre em `http://localhost/phpmyadmin`.
4. Importe `database/schema.sql`. O script cria o banco `nautica325`, as cinco tabelas, as dez categorias e os sete produtos solicitados.
5. Confira o arquivo `.env` na raiz. Ele está preenchido para o XAMPP padrão (`localhost`, banco `nautica325`, usuário `root` e senha vazia). Ajuste caso suas credenciais sejam diferentes.
6. Acesse `http://localhost/nautica325/`.

## 3. Criar o administrador

Não existe uma senha administrativa fixa no código. Crie uma conta administrativa pelo terminal, a partir da pasta do projeto:

```bash
php scripts/criar_admin.php admin@nautica325.local "EscolhaUmaSenhaForte123!" "Administrador"
```

Use o e-mail e a senha informados para entrar pela página `login.php`. O usuário com perfil `admin` terá acesso ao menu Administração e à pasta `/admin`.

> Se o comando `php` não for reconhecido no terminal do Windows, execute usando o caminho do PHP do XAMPP:
>
> `C:\\xampp\\php\\php.exe scripts/criar_admin.php admin@nautica325.local "EscolhaUmaSenhaForte123!" "Administrador"`

## 4. Fluxo de teste

1. Na home, veja os destaques ou use a busca e os filtros de categoria e preço.
2. Abra um produto para ver descrição, SKU, preço e disponibilidade.
3. Adicione itens ao carrinho. Altere quantidades ou remova produtos.
4. Crie uma conta de cliente e faça login.
5. Acesse o checkout, escolha PIX, Boleto ou Cartão de Crédito e confirme o pedido.
6. O sistema registra o pedido e seus itens, guarda o preço unitário vendido, reduz o estoque dentro de uma transação SQL e limpa o carrinho da sessão.
7. Entre com o administrador para gerenciar produtos, consultar pedidos e visualizar clientes.

## 5. Segurança implementada

- Credenciais lidas do `.env`; o arquivo real é ignorado pelo Git. O repositório mantém `.env.example`.
- Arquivos `.htaccess` desativam listagem de diretórios e bloqueiam acesso HTTP direto ao `.env`, à lógica interna (`app/`), aos scripts CLI e ao SQL de instalação.
- PDO com prepared statements e `ATTR_EMULATE_PREPARES=false`.
- Senhas protegidas por `password_hash()` e verificadas com `password_verify()`.
- Sessões com `HttpOnly`, `SameSite=Lax` e regeneração do ID após login.
- Verificação de perfil administrativo no servidor em todas as rotas `/admin`.
- Tokens CSRF em formulários que alteram dados.
- Escape de saída HTML com `htmlspecialchars()`.
- Checkout com transação de banco, bloqueio dos produtos para leitura (`FOR UPDATE`) e validação final do estoque.
- Métodos de pagamento são apenas simulações: não são solicitados dados de cartão e não há integração com adquirente.

## 6. Banco de dados

O arquivo `database/schema.sql` cria:

- `usuarios`: clientes e administradores, e-mail único e hash de senha.
- `categorias`: dez categorias de produtos.
- `produtos`: SKU único, categoria, descrição, preço decimal, estoque, imagem, status e destaque.
- `pedidos`: usuário, forma de pagamento, total, status e data.
- `itens_pedido`: relação entre pedidos e produtos, quantidade e preço unitário congelado, além de cópia do nome e SKU para preservar o histórico.

Há chaves primárias, estrangeiras, restrições `UNIQUE` e índices.

## 7. Estrutura do projeto

```text
nautica325/
├── admin/                 # Dashboard e gestão de produtos, pedidos e clientes
├── app/
│   ├── bootstrap.php      # .env, sessão e cabeçalhos de segurança
│   ├── database.php       # Conexão PDO
│   ├── auth.php           # Autenticação e autorização
│   ├── helpers.php        # CSRF, carrinho, escaping e utilitários
│   └── views/             # Cabeçalho, rodapé e card de produto
├── assets/
│   ├── css/style.css
│   ├── js/app.js
│   └── images/            # Ilustrações SVG locais
├── database/schema.sql
├── scripts/criar_admin.php
├── .env                   # Configuração local; não enviar ao Git
├── .env.example
├── .gitignore
└── index.php
```

## 8. Git e entrega

O arquivo `.gitignore` exclui `.env`, dependências, logs e arquivos de sistema. Antes de enviar o repositório, confira se `.env` não foi adicionado ao Git.

Exemplo de histórico de desenvolvimento (faça os commits à medida que concluir cada etapa; não crie um único commit contendo todo o projeto pronto):

```bash
git init
git add .gitignore .env.example README.md database/schema.sql
git commit -m "chore: estrutura e modelagem inicial do banco"

git add app assets index.php produto.php
git commit -m "feat: identidade visual e catálogo de produtos"

git add cadastro.php login.php logout.php
git commit -m "feat: cadastro e autenticação de usuários"

git add carrinho.php adicionar_carrinho.php atualizar_carrinho.php remover_carrinho.php
git commit -m "feat: carrinho com validação de estoque"

git add checkout.php finalizar_pedido.php pedido_concluido.php meus_pedidos.php
git commit -m "feat: checkout e registro de pedidos"

git add admin scripts
git commit -m "feat: painel administrativo e gestão da loja"
```

Crie um repositório no GitHub e conecte:

```bash
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/nautica325.git
git push -u origin main
```

**Atenção:** não publique `.env`, senhas ou credenciais reais. Este pacote inclui `.env` para facilitar o uso local no XAMPP, mas ele deve permanecer fora do repositório remoto.
