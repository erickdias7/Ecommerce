<?php
require __DIR__ . '/app/bootstrap.php';
require_login();
$stmt = db()->prepare("SELECT * FROM pedidos WHERE usuario_id=:id ORDER BY created_at DESC");
$stmt->execute(['id'=>current_user()['id']]);
$pedidos = $stmt->fetchAll();
$pageTitle = 'Meus pedidos';
require __DIR__ . '/app/views/header.php';
?>
<main class="container page-wrap"><div class="page-heading"><div><span class="eyebrow">ÁREA DO CLIENTE</span><h1>Meus pedidos</h1></div></div>
<?php if (!$pedidos): ?><div class="empty-state"><i class="bi bi-receipt"></i><h3>Você ainda não tem pedidos</h3><a class="btn btn-navy" href="index.php">Explorar produtos</a></div><?php else: ?>
<div class="table-responsive table-card"><table class="table align-middle"><thead><tr><th>Pedido</th><th>Data</th><th>Pagamento</th><th>Total</th><th>Status</th></tr></thead><tbody>
<?php foreach ($pedidos as $p): ?><tr><td>#<?= (int)$p['id'] ?></td><td><?= e(date('d/m/Y H:i',strtotime($p['created_at']))) ?></td><td><?= e($p['forma_pagamento']) ?></td><td><?= money($p['total']) ?></td><td><?= e($p['status']) ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
