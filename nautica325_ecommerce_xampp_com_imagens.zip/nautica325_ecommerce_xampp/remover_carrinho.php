<?php
require __DIR__ . '/app/bootstrap.php';
require_post();
verify_csrf();
$id = filter_var($_POST['produto_id'] ?? 0, FILTER_VALIDATE_INT);
if ($id) unset($_SESSION['carrinho'][$id]);
flash('success', 'Produto removido do carrinho.');
redirect('carrinho.php');
