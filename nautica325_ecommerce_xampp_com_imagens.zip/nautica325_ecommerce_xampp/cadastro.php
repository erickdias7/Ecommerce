<?php
require __DIR__ . '/app/bootstrap.php';
if (current_user()) redirect('index.php');
$erros = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nome = trim((string)($_POST['nome'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $senha = (string)($_POST['senha'] ?? '');
    if (mb_strlen($nome) < 2) $erros[] = 'Informe seu nome completo.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erros[] = 'Informe um e-mail válido.';
    if (strlen($senha) < 8) $erros[] = 'A senha deve ter pelo menos 8 caracteres.';
    if (!$erros) {
        try {
            $stmt = db()->prepare("INSERT INTO usuarios (nome,email,senha,perfil) VALUES (:nome,:email,:senha,'cliente')");
            $stmt->execute(['nome'=>$nome,'email'=>$email,'senha'=>password_hash($senha,PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['usuario'] = ['id'=>(int)db()->lastInsertId(),'nome'=>$nome,'email'=>$email,'perfil'=>'cliente'];
            flash('success','Cadastro realizado. Você já pode continuar.');
            redirect('index.php');
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') $erros[] = 'Este e-mail já está cadastrado.';
            else throw $e;
        }
    }
}
$pageTitle = 'Criar conta';
require __DIR__ . '/app/views/header.php';
?>
<main class="container auth-wrap"><form class="auth-card" method="post"><span class="eyebrow">NÁUTICA325 · SUA CONTA</span><h1>Criar cadastro</h1><p>Crie sua conta para acompanhar e finalizar pedidos.</p><?= csrf_field() ?>
<?php foreach ($erros as $erro): ?><div class="alert alert-danger"><?= e($erro) ?></div><?php endforeach; ?>
<label>Nome completo<input class="form-control" name="nome" required maxlength="140" value="<?= e($_POST['nome'] ?? '') ?>"></label>
<label>E-mail<input class="form-control" type="email" name="email" required maxlength="190" value="<?= e($_POST['email'] ?? '') ?>"></label>
<label>Senha<input class="form-control" type="password" name="senha" required minlength="8"></label>
<button class="btn btn-navy w-100 mt-3">Criar conta</button><p class="auth-note">Já tem cadastro? <a href="login.php">Entrar</a></p></form></main>
<?php require __DIR__ . '/app/views/footer.php'; ?>
