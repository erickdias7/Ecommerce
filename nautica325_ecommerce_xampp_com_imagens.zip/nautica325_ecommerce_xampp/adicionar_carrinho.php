<?php
require __DIR__ . '/app/bootstrap.php';
require_post();
verify_csrf();
$id = filter_var($_POST['produto_id'] ?? 0, FILTER_VALIDATE_INT);
$quantidade = filter_var($_POST['quantidade'] ?? 1, FILTER_VALIDATE_INT);
$quantidade = $quantidade ? (int)$quantidade : 1;
$stmt = db()->prepare("SELECT id, nome, estoque FROM produtos WHERE id=:id AND ativo=1 LIMIT 1");
$stmt->execute(['id' => $id ?: 0]);
$produto = $stmt->fetch();
if (!$produto || (int)$produto['estoque'] < 1) {
    flash('error', 'Este produto está indisponível.');
    redirect('index.php');
}
$atual = (int)($_SESSION['carrinho'][$id] ?? 0);
if ($quantidade < 1 || $atual + $quantidade > (int)$produto['estoque']) {
    flash('error', 'A quantidade solicitada ultrapassa o estoque disponível.');
    redirect('produto.php?id=' . (int)$id);
}
$_SESSION['carrinho'][$id] = $atual + $quantidade;
flash('success', 'Produto adicionado ao carrinho.');
redirect('carrinho.php');
