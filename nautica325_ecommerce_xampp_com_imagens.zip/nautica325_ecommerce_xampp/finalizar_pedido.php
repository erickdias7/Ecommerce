<?php
require __DIR__ . '/app/bootstrap.php';
require_post();
require_login();
verify_csrf();
$forma = (string)($_POST['forma_pagamento'] ?? '');
if (!in_array($forma, ['PIX','Boleto','Cartão de Crédito'], true)) {
    flash('error','Selecione uma forma de pagamento válida.');
    redirect('checkout.php');
}
$itensSessao = $_SESSION['carrinho'] ?? [];
if (!$itensSessao) {
    flash('error','Seu carrinho está vazio.');
    redirect('carrinho.php');
}

$pdo = db();
try {
    $pdo->beginTransaction();
    $consulta = $pdo->prepare("SELECT id,nome,sku,preco,estoque,ativo FROM produtos WHERE id=:id FOR UPDATE");
    $produtos = [];
    $total = 0.0;

    foreach ($itensSessao as $id => $quantidade) {
        $consulta->execute(['id'=>(int)$id]);
        $produto = $consulta->fetch();
        $qtd = (int)$quantidade;
        if (!$produto || !(int)$produto['ativo'] || $qtd < 1 || $qtd > (int)$produto['estoque']) {
            throw new RuntimeException('Estoque insuficiente ou produto indisponível. Revise o carrinho.');
        }
        $produto['quantidade'] = $qtd;
        $total += (float)$produto['preco'] * $qtd;
        $produtos[] = $produto;
    }

    $pedido = $pdo->prepare("INSERT INTO pedidos (usuario_id,forma_pagamento,total,status) VALUES (:usuario,:forma,:total,'confirmado')");
    $pedido->execute(['usuario'=>current_user()['id'],'forma'=>$forma,'total'=>number_format($total,2,'.','')]);
    $pedidoId = (int)$pdo->lastInsertId();

    $itemInsert = $pdo->prepare("INSERT INTO itens_pedido (pedido_id,produto_id,nome_produto,sku,quantidade,preco_unitario) VALUES (:pedido,:produto,:nome,:sku,:quantidade,:preco)");
    $estoqueUpdate = $pdo->prepare("UPDATE produtos SET estoque=estoque-:qtd WHERE id=:id AND estoque>=:qtd");

    foreach ($produtos as $produto) {
        $itemInsert->execute([
            'pedido'=>$pedidoId,'produto'=>$produto['id'],'nome'=>$produto['nome'],'sku'=>$produto['sku'],
            'quantidade'=>$produto['quantidade'],'preco'=>number_format((float)$produto['preco'],2,'.','')
        ]);
        $estoqueUpdate->execute(['qtd'=>$produto['quantidade'],'id'=>$produto['id']]);
        if ($estoqueUpdate->rowCount() !== 1) throw new RuntimeException('Não foi possível atualizar o estoque.');
    }

    $pdo->commit();
    unset($_SESSION['carrinho']);
    redirect('pedido_concluido.php?id='.$pedidoId);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    flash('error', $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível concluir o pedido. Tente novamente.');
    redirect('carrinho.php');
}
