<?php
require __DIR__ . '/app/bootstrap.php';
require_post();
verify_csrf();
$id = filter_var($_POST['produto_id'] ?? 0, FILTER_VALIDATE_INT);
$qtd = filter_var($_POST['quantidade'] ?? 0, FILTER_VALIDATE_INT);
$stmt = db()->prepare("SELECT estoque FROM produtos WHERE id=:id AND ativo=1 LIMIT 1");
$stmt->execute(['id' => $id ?: 0]);
$produto = $stmt->fetch();
if (!$produto || !$qtd || $qtd < 1 || $qtd > (int)$produto['estoque']) {
    flash('error', 'Quantidade inválida ou acima do estoque disponível.');
} else {
    $_SESSION['carrinho'][$id] = (int)$qtd;
    flash('success', 'Carrinho atualizado.');
}
redirect('carrinho.php');
